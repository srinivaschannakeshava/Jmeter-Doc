#!/bin/sh

java -jar demo.jar