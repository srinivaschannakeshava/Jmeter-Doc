I have included the CSV file with the users of the application and the scripts of each clip of the module (including the home controller fragment).

To open them in JMeter, go to File -> Open.

Remember to install the plugin Custom Thread Groups (https://jmeter-plugins.org/wiki/ConcurrencyThreadGroup/) for scripts 05 and 06.

Tool to build CSS Selectors
https://try.jsoup.org/

Tool to build Regular Expressions
https://regexr.com/

JMeter's Functions Documentation
https://jmeter.apache.org/usermanual/functions.html