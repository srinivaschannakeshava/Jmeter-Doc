I have included the scripts of clips 02, 03, and 04 (and the CSV file for users).

To open them in JMeter, go to File -> Open.

Remember to install the plugins:
- Custom Thread Groups (https://jmeter-plugins.org/wiki/ConcurrencyThreadGroup/)
- 3 Basic Graphs (https://jmeter-plugins.org/wiki/ResponseTimesOverTime/)
- PerfMon (https://jmeter-plugins.org/wiki/PerfMon/)

PerfMon Server Agent
https://github.com/undera/perfmon-agent/

JMeter Dashboard Report
http://jmeter.apache.org/usermanual/generating-dashboard.html